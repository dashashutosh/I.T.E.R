
public class Program_3 {

	public static void main(String[] args) {
	System.out.println("           A                   D D D D ");
	System.out.println("         A   A                 D     D"    );
    System.out.println("       A       A               D     D "    );
	System.out.println("     AAAAAAAAAAAAA             D     D "    );
	System.out.println("   A               A           D     D "    );
	System.out.println(" A                   A         D D D D ");                     
	
	}

}
