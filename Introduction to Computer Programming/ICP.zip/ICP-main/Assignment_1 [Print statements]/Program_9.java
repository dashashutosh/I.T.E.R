
public class Program_9 {

	public static void main(String[] args) {
		System.out.println(2+ "bc");
		System.out.println(2+3+"bc");
		System.out.println((2+3)+"bc");
		System.out.println("bc"+ (2+3));
		System.out.println("bc"+2+3);

	}

}
