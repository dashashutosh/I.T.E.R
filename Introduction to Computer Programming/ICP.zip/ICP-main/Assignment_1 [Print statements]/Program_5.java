
public class Program_5 {

	public static void main(String[] args) {
		int rno= 1941012274;
		int yr= 2019;
		System.out.println("My Regd. No is "+rno+ " and I have taken admission in B.Tech In "+yr);
		
	}

}
