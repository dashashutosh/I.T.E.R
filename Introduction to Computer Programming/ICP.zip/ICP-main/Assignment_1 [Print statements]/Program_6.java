
public class Program_6 {

	public static void main(String[] args) {
		int x=113;
		double y=2.71828;
		System.out.println("This is room # "+x);
		System.out.println("e is close to "+y);

	}

}
