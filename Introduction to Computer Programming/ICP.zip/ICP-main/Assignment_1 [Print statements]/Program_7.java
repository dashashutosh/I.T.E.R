
public class Program_7 {
	

	public static void main(String[] args) {

        int a=1;
        int b=2;
        int c=a;
        a=b;
        b=c;
        System.out.println(a);
        System.out.println(b);
        
	}
  
}	
