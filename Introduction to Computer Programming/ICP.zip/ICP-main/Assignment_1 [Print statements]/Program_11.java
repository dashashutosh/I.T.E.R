
public class Program_11 {

	public static void main(String[] args) {
		int a=2147483647;
		System.out.println(a);
		System.out.println(a+1);
		System.out.println(2-a);
		System.out.println(-2-a);
		System.out.println(2*a);
		System.out.println(4*a);
		

	}

}
