
public class Program_12 {

	public static void main(String[] args) {
		double a=3.14159;
		System.out.println(a);
		System.out.println(a+1);
		System.out.println(8/(int)a);
		System.out.println(8/a);
		System.out.println((int)(8/a));

	}

}
