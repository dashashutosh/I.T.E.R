
public class Program_13 {
	
	public static void main(String[] args) {
		
		String ruler1="1";
		System.out.println(ruler1);
		System.out.println(ruler1+" 2 "+ruler1);
		ruler1=ruler1+" 2 "+ruler1;
		System.out.println(ruler1+ " 3 "+ruler1);
		ruler1=ruler1+ " 3 "+ruler1;
		System.out.println(ruler1+ " 4 "+ruler1);
	}

}
