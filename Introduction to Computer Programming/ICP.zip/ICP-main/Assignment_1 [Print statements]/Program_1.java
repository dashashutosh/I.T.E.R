
public class Program_1 {

	
public static void main(String[] args) {
		
System.out.println("Hello World!");
		
System.out.println("Hello Again");
		
System.out.println("I like typing this.");

		System.out.println("This is fun.");

		System.out.println("Yay! Printing.");

		System.out.println("I'd much rather you 'not'.");

		System.out.println("I \"said\" do not touch this.");

		


	}

}
