
public class a4q6 {

	public static void main(String[] args) {
		int i;
		for(i=1001;i<=2000;i++)
		{
			System.out.print(i+" ");
			if(i%5==0)
			{
			  System.out.println(" ");
			}
		}
   
	}
}

