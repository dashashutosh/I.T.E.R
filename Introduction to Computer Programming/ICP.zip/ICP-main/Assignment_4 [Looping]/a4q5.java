
public class a4q5 {

	public static void main(String[] args) {
		double m=0.5,x;
		for(x=-2;x<=2;x=x+m)
		{
			System.out.println(x);
		}

	}

}
