import java.util.Scanner;


public class Program_3 {

	
public static void main(String[] args) {
		
Scanner sc=new Scanner(System.in);
		
double F,M;
		
System.out.println("Enter the value of F");
	
	F=sc.nextDouble();
	
	M=0.305*F;
		
System.out.println(F+"F"+M+"M");
	
}

}
