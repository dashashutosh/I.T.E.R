import java.util.Scanner;


public class Program_2 {

	public static void main(String[] args) 
	{
		Scanner imput =new Scanner(System.in);
		System.out.println("Enter the R of the cylinder");
		double R,L,A,V;
		R=imput.nextDouble();
		System.out.println("Enter the L of the cylinder");
		L=imput.nextDouble();
		A=R*R*3.14;
		V=L*A;
	    System.out.println("the A is"+A);
	    System.out.println("the L is"+L);
	    
	    
	    
		
		
		

	}

}
