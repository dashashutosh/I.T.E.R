
public class Program_6 {

	public static void main(String[] args) {
		Scanner imput =new Scanner(System.in);
		System.out.println("Enter the W");
		

	}

}
