
public class Program_14 {

	public static void main(String[] args) {
		int a,b;
		a=Integer.parseInt(args[0]);
		b=Integer.parseInt(args[1]);
		boolean p= (a%b==0)||(b%a==0);
		System.out.println(p);

	}

}
