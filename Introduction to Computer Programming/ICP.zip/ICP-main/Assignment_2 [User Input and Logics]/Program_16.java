
public class Program_16 {

	public static void main(String[] args) {
		int a=6,b=1;
		int x=(int)(Math.random()*(a-b+1))+b;
		int y=(int)(Math.random()*(a-b+1))+b;
		System.out.println(x+y);

	}

}
