
public class program_19 {

	public static void main(String[] args) {
		double bs,da,hra,gs;
		bs=Double.parseDouble(args[0]);
		da=0.4*bs;
		hra=0.2*bs;
		gs=bs+da+hra;
		System.out.println("gross salary is "+gs);
		

	}

}
