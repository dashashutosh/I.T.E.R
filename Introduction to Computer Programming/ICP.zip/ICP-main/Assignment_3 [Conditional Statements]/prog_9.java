
public class prog_9 {

	public static void main(String[] args) {
		int max=12;
		int min=1;
		int m=(int)(Math.random()*(max-min)+1)+min;
		if(m==1)
		{
			System.out.println("its january");
		}
		else if(m==2)
		{
			System.out.println("its february");
		}
		else if(m==3)
		{
			System.out.println("its march");
		}
		else if(m==4)
		{
			System.out.println("its april");
		}
		else if(m==5)
		{
			System.out.println("its may");
		}
		else if(m==6)
		{
			System.out.println("its june");
		}
		else if(m==7)
		{
			System.out.println("its july");
		}
		else if(m==8)
		{
			System.out.println("its august");
		}
		else if(m==9)
		{
			System.out.println("its september");
		}
		else if(m==10)
		{
			System.out.println("its october");
		}
		else if(m==11)
		{
			System.out.println("its november");
		}
		else if(m==12)
		{
			System.out.println("its december");
		}
       
       else
	   {
		System.out.println("invalid entry");
	   }

}
}